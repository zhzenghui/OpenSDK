//
//  ViewController.h
//  WebView
//
//  Created by kingsky on 15/12/15.
//  Copyright © 2015年 youku.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIWebViewDelegate>

{
    
    UIWebView *webView;
    
    UIActivityIndicatorView *activityIndicatorView;
    
}

@end