//
//  AppDelegate.h
//  WebView
//
//  Created by kingsky on 15/12/15.
//  Copyright © 2015年 youku.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

