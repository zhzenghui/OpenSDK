//
//  VersionsLog.h
//  YouTuEngineMediaPlayer
//
//  Created by 韦兴华 on 15/4/20.
//  Copyright (c) 2015年 Youku Inc. All rights reserved.
//

//  该文件记录“播放器SDK for Youku”的版本纪录

/*
 ** @version 3.0
 ** @new feature
    1.
    2.
    ...
 ** @improvements
    1.
    2.
    ...
 ** @fix bugs
    1.
    ...
*/