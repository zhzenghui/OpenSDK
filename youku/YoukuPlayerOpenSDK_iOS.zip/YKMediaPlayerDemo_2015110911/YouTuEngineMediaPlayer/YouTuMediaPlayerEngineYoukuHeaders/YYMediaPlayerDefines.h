//
//  YYMediaPlayerDefines.h
//  YoukuMediaPlayer
//
//  Created by kevin on 14-7-16.
//  Copyright (c) 2014年 Youku Inc. All rights reserved.
//

#ifndef YoukuMediaPlayer_YYMediaPlayerDefines_h
#define YoukuMediaPlayer_YYMediaPlayerDefines_h

#ifdef __cplusplus
#define YY_EXTERN		extern "C" __attribute__((visibility ("default")))
#else
#define YY_EXTERN	    extern __attribute__((visibility ("default")))
#endif

#endif //YoukuMediaPlayer_YYMediaPlayerDefines_h
