//
//  YTEngineOpenViewPlayer.h
//  YouTuEngineMediaPlayer
//
//  Created by 周娜 on 15/10/12.
//  Copyright (c) 2015年 Youku Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YoukuMediaPlayer.h"

@class YTEngineReachability;

@interface YTEngineOpenViewPlayer : UIViewController

@property (nonatomic, retain) YYMediaPlayer *player;

@end
