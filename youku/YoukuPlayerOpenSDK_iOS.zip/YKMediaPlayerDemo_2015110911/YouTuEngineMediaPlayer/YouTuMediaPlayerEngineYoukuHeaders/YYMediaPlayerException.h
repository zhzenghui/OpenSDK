//
//  YYMediaPlayerException.h
//  YoukuMediaPlayer
//
//  Created by 韦兴华 on 14-5-13.
//  Copyright (c) 2014年 Youku Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YYMediaPlayerException : NSException

@end