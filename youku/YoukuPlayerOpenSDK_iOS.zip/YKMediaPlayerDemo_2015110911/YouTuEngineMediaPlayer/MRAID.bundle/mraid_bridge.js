/**
 *
 */
(function() {
 
 var mraidview = window.mraidview = {};
 
 
 /** Expand Properties */
 var expandProperties = {
 useBackground:false,
 backgroundColor:'#ffffff',
 backgroundOpacity:1.0,
 lockOrientation:false
 };
 
 var orientationProperties = {
 /* If set to 'true' then the container will permit device-based orientation changes; if set to false, then the container will ignore device-based orientation changes (e.g., the web view will not change even if the orientation of the device changes). Default is 'true.' The ad creative is always able to request a change of its orientation by setting the forceOrientation variable, regardless of how allowOrientationChange is set. */
 allowOrientationChange : true,
 /* can be set to a value of 'portrait', 'landscape or 'none' If forceOrientation is set then a view must open in the specified orientation, regardless of the orientation of the device. That is, if a user is viewing an ad in landscape mode, and taps to expand it, if the ad designer has set the forceOrientation orientation property to 'portrait' then the ad will open in portrait orientation. Default is 'none.' */
 forceOrientation : "none"
 };
 
 var resizeProperties = {
 /* (required) integer ®C width of creative in pixels */
 width : 0,
 /* height : (required) integer ®C height of creative in pixels */
 height : 0,
 /* offsetX: (required) is the horizontal delta from the banner's upper left-hand corner where the upper left-hand corner of the expanded region should be placed; positive integers for expand right; negative for left */
 offsetX : 0,
 /* offsetY: (required) is the vertical delta from the banner's upper left-hand corner where the upper left-hand corner of the expanded region should be placed; positive integers for expand down; negative for up */
 offsetY : 0,
 /* customClosePosition: (optional) string ®C either top-left, top-right, center, bottom-left, bottom-right, top-center, or bottom-center indicates the origin of the container-supplied close event region relative to the resized creative. If not specified or not one of these options, will default to top-right */
 customClosePosition : 'top-right',
 /*
  * allowOffscreen: (optional) tells the container whether or not it should allow the resized creative to be drawn fully/partially offscreen
  *
  * True (default): the container should not attempt to position the resized creative
  * False: the container should try to reposition the resized creative to always fit in the getMaxSize() area
  */
 allowOffscreen : true
 };
 
 
 /** The set of listeners for ORMMA Native Bridge Events */
 var listeners = { };
 
 
 /** A Queue of Calls to the Native SDK that still need execution */
 var nativeCallQueue = [ ];
 
 /** Identifies if a native call is currently in progress */
 var nativeCallInFlight = false;
 
 /** timer for identifying iframes */
 var timer;
 var totalTime;
 
 
 
 /**********************************************/
 /********** OBJECTIVE-C ENTRY POINTS **********/
 /**********************************************/
 
 /**
  * Called by the Objective-C SDK when an asset has been fully cached.
  *
  * @returns string, "OK"
  */
 mraidview.fireAssetReadyEvent = function( alias, URL ) {
 var handlers = listeners["assetReady"];
 if ( handlers != null ) {
 for ( var i = 0; i < handlers.length; i++ ) {
 handlers[i]( alias, URL );
 }
 }
 
 return "OK";
 };
 
 
 mraidview.useCustomClose = function( flag ) {
 this.executeNativeCall( "useCustomClose",
                        "useCustomClose", ( flag == 'true' || flag == true)? 'Y' : 'N' );
 
 }
 
 /**
  * Called by the Objective-C SDK when an asset has been removed from the
  * cache at the request of the creative.
  *
  * @returns string, "OK"
  */
 mraidview.fireAssetRemovedEvent = function( alias ) {
 var handlers = listeners["assetRemoved"];
 if ( handlers != null ) {
 for ( var i = 0; i < handlers.length; i++ ) {
 handlers[i]( alias );
 }
 }
 
 return "OK";
 };
 
 
 /**
  * Called by the Objective-C SDK when an asset has been automatically
  * removed from the cache for reasons outside the control of the creative.
  *
  * @returns string, "OK"
  */
 mraidview.fireAssetRetiredEvent = function( alias ) {
 var handlers = listeners["assetRetired"];
 if ( handlers != null ) {
 for ( var i = 0; i < handlers.length; i++ ) {
 handlers[i]( alias );
 }
 }
 
 return "OK";
 };
 
 
 /**
  * Called by the Objective-C SDK when various state properties have changed.
  *
  * @returns string, "OK"
  */
 mraidview.fireChangeEvent = function(properties){
 var handlers = listeners["change"];
 if ( handlers != null ) {
 for ( var i = 0; i < handlers.length; i++ ) {
 handlers[i]( properties );
 }
 }
 return "OK";
 };
 
 
 mraidview.test=function(properties){
// alert('test-->'+properties);
 };
 
 /**
  * Called by the Objective-C SDK when an error has occured.
  *
  * @returns string, "OK"
  */
 mraidview.fireErrorEvent = function( message, action ) {
 var handlers = listeners["error"];
 if ( handlers != null ) {
 for ( var i = 0; i < handlers.length; i++ ) {
 handlers[i]( message, action );
 }
 }
 
 return "OK";
 };
 
 
 /**
  * Called by the Objective-C SDK when the user shakes the device.
  *
  * @returns string, "OK"
  */
 mraidview.fireShakeEvent = function() {
 var handlers = listeners["shake"];
 if ( handlers != null ) {
 for ( var i = 0; i < handlers.length; i++ ) {
 handlers[i]();
 }
 }
 
 return "OK";
 };
 
 
 /**
  * nativeCallComplete notifies the abstraction layer that a native call has
  * been completed..
  *
  * NOTE: This function is called by the native code and is not intended to be
  *       used by anything else.
  *
  * @returns string, "OK"
  */
 mraidview.nativeCallComplete = function( cmd ) {
 
 // anything left to do?
 if ( nativeCallQueue.length == 0 ) {
 nativeCallInFlight = false;
 return;
 }
 
 // still have something to do
 var bridgeCall = nativeCallQueue.pop();
 window.location = bridgeCall;
 
 return "OK";
 };
 
 
 /**
  *
  */
 mraidview.showAlert = function( message ) {
// alert( message );
 };
 
 
 /*********************************************/
 /********** INTERNALLY USED METHODS **********/
 /*********************************************/
 
 
 /**
  *
  */
 mraidview.zeroPad = function( number ) {
 var text = "";
 if ( number < 10 ) {
 text += "0";
 }
 text += number;
 return text;
 }
 
 /**
  *
  */
 mraidview.executeNativeCall = function( command ) {
 // build iOS command
 var bridgeCall = "mraid://" + command;
 var value;
 var firstArg = true;
 for ( var i = 1; i < arguments.length; i += 2 ) {
 value = arguments[i + 1];
 if ( value == null ) {
 // no value, ignore the property
 continue;
 }
 
 // add the correct separator to the name/value pairs
 if ( firstArg ) {
 bridgeCall += "?";
 firstArg = false;
 }
 else {
 bridgeCall += "&";
 }
 bridgeCall += arguments[i] + "=" + escape( value );
 }
 
 // add call to queue
 if ( nativeCallInFlight ) {
 // call pending, queue up request
 nativeCallQueue.push( bridgeCall );
 }
 else {
 // no call currently in process, execute it directly
 nativeCallInFlight = true;
 window.location = bridgeCall;
 }
 };
 
 
 
 /***************************************************************************/
 /********** LEVEL 0 (not part of spec, but required by public API **********/
 /***************************************************************************/
 
 /**
  *
  */
 mraidview.activate = function( event ) {
 this.executeNativeCall( "service",
                        "name", event,
                        "enabled", "Y" );
 };
 
 
 /**
  *
  */
 mraidview.addEventListener = function( event, listener ) {
 var handlers = listeners[event];
 if ( handlers == null ) {
 // no handlers defined yet, set it up
 listeners[event] = [];
 handlers = listeners[event];
 }
 
 // see if the listener is already present
 for ( var handler in handlers ) {
 if ( listener == handler ) {
 // listener already present, nothing to do
 return;
 }
 }
 
 // not present yet, go ahead and add it
 handlers.push( listener );
 };
 
 
 /**
  *
  */
 mraidview.deactivate = function( event ) {
 this.executeNativeCall( "service",
                        "name", event,
                        "enabled", "N" );
 };
 
 
 /**
  *
  */
 mraidview.removeEventListener = function( event, listener ) {
 var handlers = listeners[event];
 if ( handlers != null ) {
 handlers.remove( listener );
 }
 };
 
 
 
 /*****************************/
 /********** LEVEL 1 **********/
 /*****************************/
 
 /**
  *
  */
 mraidview.close = function() {
 this.executeNativeCall( "close" );
 };
 
 /**
  *
  *
  *
  */
 mraidview.share = function( message/*:String*/ ) {
 this.executeNativeCall( "share","message", message);
 };
 
 /**
  *
  */
 mraidview.expand = function( dimensions, URL ) {
 try {
 var cmd = "this.executeNativeCall( 'expand'";
 if ( URL != null ) {
 cmd += ", 'url', '" + URL + "'";
 }
 if ( ( typeof dimensions.x != "undefined" ) && ( dimensions.x != null ) ) {
 cmd += ", 'x', '" + dimensions.x + "'";
 }
 if ( ( typeof dimensions.y != "undefined" ) && ( dimensions.y != null ) ) {
 cmd += ", 'y', '" + dimensions.y + "'";
 }
 if ( ( typeof dimensions.width != "undefined" ) && ( dimensions.width != null ) ) {
 cmd += ", 'w', '" + dimensions.width + "'";
 }
 if ( ( typeof dimensions.height != "undefined" ) && ( dimensions.height != null ) ) {
 cmd += ", 'h', '" + dimensions.height + "'";
 }
 if ( ( typeof expandProperties.useBackground != "undefined" ) && ( expandProperties.useBackground != null ) ) {
 cmd += ", 'useBG', '" + ( expandProperties.useBackground ? "Y" : "N" ) + "'";
 }
 if ( ( typeof expandProperties.backgroundColor != "undefined" ) && ( expandProperties.backgroundColor != null ) ) {
 cmd += ", 'bgColor', '" + expandProperties.backgroundColor + "'";
 }
 if ( ( typeof expandProperties.backgroundOpacity != "undefined" ) && ( expandProperties.backgroundOpacity != null ) ) {
 cmd += ", 'bgOpacity', " + expandProperties.backgroundOpacity;
 }
 if ( ( typeof expandProperties.lockOrientation != "undefined" ) && ( expandProperties.lockOrientation != null ) ) {
 cmd += ", 'lkOrientation', '" + ( expandProperties.lockOrientation ? "Y" : "N" ) + "'";
 }
 
 
 
 cmd += " );";
 eval( cmd );
 } catch ( e ) {
// alert( "executeNativeExpand: " + e + ", cmd = " + cmd );
 }
 };
 
 /**
  *
  */
 mraidview.hide = function() {
 this.executeNativeCall( "hide" );
 };
 
 /**
  *
  */
 mraidview.open = function( URL, controls ) {
 // the navigation parameter is an array, break it into its parts
 var back = false;
 var forward = false;
 var refresh = false;
 if ( controls == null ) {
 back = true;
 forward = true;
 refresh = true;
 }
 else {
 for ( var i = 0; i < controls.length; i++ ) {
 if ( ( controls[i] == "none" ) && ( i > 0 ) ) {
 // error
 self.fireErrorEvent( "none must be the only navigation element present.", "open" );
 return;
 }
 else if ( controls[i] == "all" ) {
 if ( i > 0 ) {
 // error
 self.fireErrorEvent( "none must be the only navigation element present.", "open" );
 return;
 }
 
 // ok
 back = true;
 forward = true;
 refresh = true;
 }
 else if ( controls[i] == "back" ) {
 back = true;
 }
 else if ( controls[i] == "forward" ) {
 forward = true;
 }
 else if ( controls[i] == "refresh" ) {
 refresh = true;
 }
 }
 }
 
 
 this.executeNativeCall( "open",
                        "url", URL,
                        "back", ( back ? "Y" : "N" ),
                        "forward", ( forward ? "Y" : "N" ),
                        "refresh", ( refresh ? "Y" : "N" ) );
 };
 
 
 /**
  *
  */
 mraidview.openMap = function( URL, fullscreen ) {
 
 this.executeNativeCall( "openMap",
                        "url", URL,
                        "fullscreen", fullscreen
                        );
 };
 
 /**
  *
  */
 mraidview.resize = function( width, height ) {
 var p = mraidview.getResizeProperties();
 this.executeNativeCall( "resize",
                        "w", width,
                        "h", height,
                        "offsetX", p.offsetX,
                        "offsetY", p.offsetY,
                        "customClosePosition", p.customClosePosition,
                        "allowOffscreen", p.allowOffscreen);
 };
 
 
 mraidview.getExpandProperties = function(){
 return expandProperties;
 }
 
 /**
  *
  */
 mraidview.setExpandProperties = function( properties ) {
 expandProperties = properties;
 };
 
 mraidview.getResizeProperties = function() {
 return resizeProperties;
 };
 /**
  *
  */
 mraidview.setResizeProperties = function( properties ) {
 resizeProperties = properties;
 };
 
 /**
  *
  */
 mraidview.show = function() {
 this.executeNativeCall( "show" );
 };
 
 
 /**
  *
  */
 mraidview.playAudio = function( URL, properties ) {
 
 var cmd = "this.executeNativeCall( 'playAudio'";
 
 cmd += ", 'url', '" + URL + "'";
 
 if ( properties != null ) {
 
 if ( ( typeof properties.autoplay != "undefined" ) && ( properties.autoplay != null ) ) {
 cmd += ", 'autoplay', 'Y'";
 }
 else{
 cmd += ", 'autoplay', 'N'";
 }
 
 if ( ( typeof properties.controls != "undefined" ) && ( properties.controls != null ) ) {
 cmd += ", 'controls', 'Y'";
 }
 else{
 cmd += ", 'controls', 'N'";
 }
 
 if ( ( typeof properties.loop != "undefined" ) && ( properties.loop != null ) ) {
 cmd += ", 'loop', 'Y'";
 }
 else{
 cmd += ", 'loop', 'N'";
 }
 
 if ( ( typeof properties.position != "undefined" ) && ( properties.position != null ) ) {
 cmd += ", 'position', 'Y'";
 }
 else{
 cmd += ", 'position', 'N'";
 }
 
 //TODO check valid values...
 
 if ( ( typeof properties.startStyle != "undefined" ) && ( properties.startStyle != null ) ) {
 cmd += ", 'startStyle', '" + properties.startStyle + "'";
 }
 else{
 cmd += ", 'startStyle', 'normal'";
 }
 
 if ( ( typeof properties.stopStyle != "undefined" ) && ( properties.stopStyle != null ) ) {
 cmd += ", 'stopStyle', '" + properties.stopStyle + "'";
 }
 else{
 cmd += ", 'stopStyle', 'normal'";
 }
 
 }
 
 cmd += " );";
 
 eval( cmd );
 };
 
 
 /**
  *
  */
 mraidview.playVideo = function( URL, properties ) {
 
 var cmd = "this.executeNativeCall( 'playVideo'";
 
 cmd += ", 'url', '" + URL + "'";
 
 if ( properties == null )properties={};
 
 if ( ( typeof properties.audio != "undefined" ) && ( properties.audio != null ) && ( properties.audio == "muted" ) ) {
 cmd += ", 'audioMuted', 'Y'";
 }
 else{
 cmd += ", 'audioMuted', 'N'";
 }
 
 
 if ( ( typeof properties.timeout != "undefined" ) && ( properties.timeout != null ) ) {
 cmd += ", 'timeout', '" + properties.timeout + "'";
 }
 else{
 cmd += ", 'timeout', '5'";
 }
 
 
 if ( ( typeof properties.autoplay != "undefined" ) && ( properties.autoplay != null ) && ( properties.autoplay == "autoplay" )) {
 cmd += ", 'autoplay', 'Y'";
 }
 else{
 cmd += ", 'autoplay', 'N'";
 }
 
 if ( ( typeof properties.controls != "undefined" ) && ( properties.controls != null ) && ( properties.controls == "controls" )) {
 cmd += ", 'controls', 'Y'";
 }
 else{
 cmd += ", 'controls', 'N'";
 }
 
 if ( ( typeof properties.loop != "undefined" ) && ( properties.loop != null ) ) {
 cmd += ", 'loop', 'Y'";
 }
 else{
 cmd += ", 'loop', 'N'";
 }
 
 if ( ( typeof properties.position != "undefined" ) && ( properties.position != null ) ) {
 cmd += ", 'position_top', '" + properties.position.top + "'";
 cmd += ", 'position_left', '" + properties.position.left + "'";
 
 if ( ( typeof properties.width != "undefined" ) && ( properties.width != null ) ) {
 cmd += ", 'position_width', '" + properties.width + "'";
 }
 else{
 //TODO ERROR
 }
 
 if ( ( typeof properties.height != "undefined" ) && ( properties.height != null ) ) {
 cmd += ", 'position_height', '" + properties.height + "'";
 }
 else{
 //TODO ERROR
 }
 }
 
 
 if ( ( typeof properties.startStyle != "undefined" ) && ( properties.startStyle != null ) ) {
 cmd += ", 'startStyle', '" + properties.startStyle + "'";
 }
 else{
 cmd += ", 'startStyle', 'normal'";
 }
 
 if ( ( typeof properties.stopStyle != "undefined" ) && ( properties.stopStyle != null ) ) {
 cmd += ", 'stopStyle', '" + properties.stopStyle + "'";
 }
 else{
 cmd += ", 'stopStyle', 'normal'";
 }
 
 
 
 cmd += " );";
 
 eval( cmd );
 
 };
 
 
 
 /*****************************/
 /********** LEVEL 2 **********/
 /*****************************/
 
 /**
  *
  */
 mraidview.createEvent = function( date, title, body ) {
 var year = date.getFullYear();
 var month = date.getMonth() + 1;
 var day = date.getDate();
 var hours = date.getHours();
 var minutes = date.getMinutes();
 
 
 var dateString = year + this.zeroPad( month ) + this.zeroPad( day ) + this.zeroPad( hours ) + this.zeroPad( minutes );
 this.executeNativeCall( "calendar",
                        "date", dateString,
                        "title", title,
                        "body", body );
 };
 
 /**
  *
  */
 mraidview.makeCall = function( phoneNumber ) {
 
 //alert('makecall mraidview simple '+phoneNumber);
 
 this.executeNativeCall( "phone",
                        "number", phoneNumber );
 };
 
 
 /**
  *
  */
 mraidview.sendMail = function( recipient, subject, body ) {
 this.executeNativeCall( "email",
                        "to", recipient,
                        "subject", subject,
                        "body", body,
                        "html", "N" );
 };
 
 
 /**
  *
  */
 mraidview.sendSMS = function( recipient, body ) {
 this.executeNativeCall( "sms",
                        "to", recipient,
                        "body", body );
 };
 
 /**
  *
  */
 mraidview.setShakeProperties = function( properties ) {
 };
 
 
 /**
  *
  */
 mraidview.pauseVideoAd = function( ) {
 try {
 this.executeNativeCall( "pauseVideoAd");
 } catch(e) {
 //mraidview.showAlert('sendSMS: ' + e);
 }
 };
 mraidview.resumeVideoAd = function( ) {
 try {
 this.executeNativeCall( "resumeVideoAd");
 } catch(e) {
 //mraidview.showAlert('sendSMS: ' + e);
 }
 };
 
 /**
  *
  */
 mraidview.getVideoAdPlayheadTime = function(){
 try {
 this.executeNativeCall( "getVideoAdPlayheadTime");
 } catch( e ) {
 return 0;
 }
 };
 mraidview.getVideoAdDuration = function(){
 try {
 this.executeNativeCall( "getVideoAdDuration");
 } catch( e ) {
 return 0;
 }
 };
 
 
 /*****************************/
 /********** LEVEL 3 **********/
 /*****************************/
 
 /**
  *
  */
 mraidview.addAsset = function( URL, alias ) {
 this.executeNativeCall( "addasset",
                        "uri", url,
                        "alias", alias );
 };
 
 
 /**
  *
  */
 mraidview.request = function( URI, display ) {
 this.executeNativeCall( "request",
                        "uri", uri,
                        "display", display );
 };
 
 
 /**
  *
  */
 mraidview.removeAsset = function( alias ) {
 this.executeNativeCall( "removeasset",
                        "alias", alias );
 };
 })();
