//
//  PlayerViewController.h
//  YKMediaPlayerDemo
//
//  Created by weixinghua on 13-6-25.
//  Copyright (c) 2013年 Youku Inc. All rights reserved.
//

#import "YTEngineOpenViewPlayer.h"

@interface PlayerViewController : YTEngineOpenViewPlayer

@end
