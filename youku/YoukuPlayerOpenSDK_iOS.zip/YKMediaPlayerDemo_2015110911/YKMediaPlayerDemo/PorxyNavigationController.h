//
//  PorxyNavigationController.h
//  YKMediaPlayerDemo
//
//  Created by weixinghua on 13-7-2.
//  Copyright (c) 2013年 Youku Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PorxyNavigationController : UINavigationController
@property (nonatomic) BOOL supportPortraitOnly;
@end
