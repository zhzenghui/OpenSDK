//
//  MainViewController.m
//  YKMediaPlayerDemo
//
//  Created by weixinghua on 13-6-25.
//  Copyright (c) 2013年 Youku Inc. All rights reserved.
//

#import "MainViewController.h"

#import "PlayerViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    [[UIApplication sharedApplication] setStatusBarHidden:NO
                                            withAnimation:NO];
    UIButton *playButton = [[UIButton alloc]initWithFrame:CGRectMake(110, 200, 100, 50)];
    [playButton setBackgroundColor:[UIColor redColor]];
    [playButton setTitle:@"Play" forState:UIControlStateNormal];
    [playButton addTarget:self action:@selector(playVideo) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:playButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)playVideo
{
    NSLog(@"play video enter!");
    [self setNewOrientation:NO];
    PlayerViewController *playerViewController = [[PlayerViewController alloc] init];
    [self.navigationController pushViewController:playerViewController animated:YES];
    [playerViewController release];
}

- (void)setNewOrientation:(BOOL)fullscreen
{
    UIDeviceOrientation lastDeviceOrien = [UIDevice currentDevice].orientation;
    UIDeviceOrientation deviceOiren = fullscreen ?
    UIDeviceOrientationLandscapeLeft : UIDeviceOrientationPortrait;
    
    if([[UIDevice currentDevice]respondsToSelector:@selector(setOrientation:)]) {
        [[UIDevice currentDevice]performSelector:@selector(setOrientation:)
                                      withObject:(id)deviceOiren];
    }
    if (lastDeviceOrien == deviceOiren) {
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 5.0) {
            [UIViewController attemptRotationToDeviceOrientation];
        }
    }
}


@end
