//
//  PlayerViewController.m
//  YKMediaPlayerDemo
//
//  Created by weixinghua on 13-6-25.
//  Copyright (c) 2013年 Youku Inc. All rights reserved.
//

#import "PlayerViewController.h"
#import "YTEngineOpenViewManager.h"

#define MARGIN 5
#define BACK_WIDTH 20
#define LEFT_FRAME_WIDH 70
#define LEFT_FRAME_HEIGHT 34
#define ui_round_34(x) ((x) < 34 ? 34 : (x))

@interface PlayerViewController ()

@property (nonatomic, retain) YTEngineOpenViewManager *viewManager;
@property (nonatomic, assign) CGRect pframe;
@property (nonatomic, retain) UIButton *backButton;

@end


@implementation PlayerViewController

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    CGSize size = self.view.bounds.size;
    CGFloat height = 180.f;
    CGFloat sheight = [UIApplication sharedApplication].statusBarFrame.size.height; //状态栏高度
    CGRect frame = CGRectMake(0, 0, size.width, height);
    
    self.player.controller = self;
    self.player.view.frame = frame;
    self.player.view.clipsToBounds = YES;
    
    //竖屏时露出状态栏
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 7) {
        CGRect bounds = CGRectMake(0, 0, size.width, size.height);
        bounds.origin.y -= sheight;
        _pframe = bounds;
        self.view.bounds = _pframe;
    }
    
    [self.view addSubview:self.player.view];
    
    [self initViews];
    
    // 配置client_id和client_secret
    self.player.clientId = @"";
    self.player.clientSecret = @"";
    
    // 初始化播放器界面管理器
    _viewManager = [[YTEngineOpenViewManager alloc] initWithPlayer:self.player];
    [self.player addEventsObserver:_viewManager];
    
    // mv: XMzU0OTQ2MDUy 爱情公寓: XNDMzNDAzNjQw 2760 韩剧: cc125c5c962411de83b1 老友记: XNTg5NTkxMzAw
    // 子宫日记:XNTg2NzYyNjY4  龙门镖局: XNTg5OTE4MDEy 琅琊榜第10集: XMTM0MzE3NTAyNA== 大好时光01: XMTM2MTIwODM4MA==
    
    // 播放视频
    NSString *vid = @"XMTM2MTIwODM4MA==";
    [self.player playVid:vid quality:kYYVideoQualityFLV password:nil from:0];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)orien
{
    if (orien == UIInterfaceOrientationPortraitUpsideDown) {
        return NO;
        
    } else {
        return [self rotatePlayer:orien];
    }
}

- (BOOL)shouldAutorotate
{
    UIInterfaceOrientation orien = [self interfaceOrientation:[UIDevice currentDevice].orientation];
    return [self rotatePlayer:orien];
}

- (BOOL)rotatePlayer:(UIInterfaceOrientation)orien
{
    if (orien == UIInterfaceOrientationPortrait &&
        self.interfaceOrientation != orien) {
        [self.player setFullscreen:NO];
        self.view.bounds = _pframe;
    } else if (UIInterfaceOrientationIsLandscape(orien)) {
        UIInterfaceOrientation corien = self.interfaceOrientation;
        if (!UIInterfaceOrientationIsLandscape(corien)) {
            [self.player setFullscreen:YES];
            self.view.bounds = [UIScreen mainScreen].bounds;
        }
    }
    return YES;
}

- (NSInteger)interfaceOrientation:(UIDeviceOrientation)orien
{
    switch (orien) {
        case UIDeviceOrientationPortrait:
            return UIInterfaceOrientationPortrait;
        case UIDeviceOrientationLandscapeLeft:
            return UIInterfaceOrientationLandscapeRight;
        case UIDeviceOrientationLandscapeRight:
            return UIInterfaceOrientationLandscapeLeft;
        default:
            return -1;
    }
}

- (void)initViews
{
    _backButton = [[UIButton alloc] init];
    UIImage *backImg = [UIImage imageNamed:@"back.png"];
    [_backButton setImage:backImg
                 forState:UIControlStateNormal];
    CGFloat h = ui_round_34(backImg.size.height);
    _backButton.bounds = CGRectMake(0, 0, BACK_WIDTH, h);
    _backButton.adjustsImageWhenHighlighted = NO;
    [_backButton addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    CGSize size = _backButton.bounds.size;
    _backButton.frame = CGRectMake(MARGIN, 0, size.width, size.height);
    [self.view addSubview:_backButton];
}

- (void)back:(UIButton *)sender {
    if (self.player.fullscreen) {
        [self setNewOrientation:!self.player.fullscreen];
    } else {
        [self.player.controller.navigationController popViewControllerAnimated:YES];
        [self.player stop];
        [self.player deinit];
        self.player = nil;
    }
}

- (void)setNewOrientation:(BOOL)fullscreen
{
    UIDeviceOrientation lastDeviceOrien = [UIDevice currentDevice].orientation;
    UIDeviceOrientation deviceOiren = fullscreen ?
    UIDeviceOrientationLandscapeLeft : UIDeviceOrientationPortrait;
    
    if([[UIDevice currentDevice]respondsToSelector:@selector(setOrientation:)]) {
        [[UIDevice currentDevice]performSelector:@selector(setOrientation:)
                                      withObject:(id)deviceOiren];
    }
    if (lastDeviceOrien == deviceOiren) {
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 5.0) {
            [UIViewController attemptRotationToDeviceOrientation];
        }
    }
}

@end
