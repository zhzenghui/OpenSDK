//
//  QZoneTableViewController.h
//  sdkDemo
//
//  Created by xiaolongzhang on 13-7-8.
//  Copyright (c) 2013年 xiaolongzhang. All rights reserved.
//

#import "SdkTableViewController.h"

@interface QZoneTableViewController : SdkTableViewController

@property (nonatomic, retain)NSString *albumId;

@end
