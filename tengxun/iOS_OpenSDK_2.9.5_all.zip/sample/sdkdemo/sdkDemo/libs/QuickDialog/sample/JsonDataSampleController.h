//
//  Created by escoz on 1/7/12.
//

#import <Foundation/Foundation.h>


@interface JsonDataSampleController : QuickDialogController {

}

@end